//
//  Student+CoreDataProperties.swift
//  CoreDataExample
//
//  Created by syed fazal abbas on 12/05/23.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var studentname: String?
    @NSManaged public var studentfather: String?
    @NSManaged public var studentaddress: String?

}

extension Student : Identifiable {

}
