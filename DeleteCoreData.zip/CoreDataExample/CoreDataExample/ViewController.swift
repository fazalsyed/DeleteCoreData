//
//  ViewController.swift
//  CoreDataExample
//
//  Created by syed fazal abbas on 12/05/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtFather: UITextField!
    @IBOutlet var txtAddress: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func btnTappedSaved(_ sender: UIButton) {
        saveData()
    }
    
    @IBAction func btnTappedShow(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FetchStudentData") as? FetchStudentData
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
extension ViewController{
    func saveData(){
        guard let Name = txtName.text else {return}
        guard let Father = txtFather.text else {return}
        guard let Address = txtAddress.text else {return}
        let collegeDict = [ "Name" : Name,
                            "Father" : Father,
                            "Address" : Address
        ]
        DataBaseHelper.shareInstance.Savedata(studentDict: collegeDict)
    }
}

