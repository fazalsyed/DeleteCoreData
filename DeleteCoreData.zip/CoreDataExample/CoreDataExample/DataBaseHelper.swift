//
//  DataBaseHelper.swift
//  CoreDataExample
//
//  Created by syed fazal abbas on 12/05/23.
//

import Foundation
import UIKit
import CoreData

class DataBaseHelper{
    
    static let shareInstance = DataBaseHelper()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    // Savedata,fetchData,deleteData
    
    func Savedata(studentDict : [String:String]){
        let student = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context!) as? Student
        student?.studentname = studentDict["Name"]
        student?.studentfather = studentDict["Father"]
        student?.studentaddress = studentDict["Address"]
        do{
            try context?.save()
        }
        catch{
            print("Data Not Saved")
        }
    }
    func fetchData() ->[Student]{
        var student = [Student]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do{
            student = try (context?.fetch(fetchRequest) as? [Student])!
        }
        catch{
            print("Not Found")
        }
        return student
    }
    
    func deleteData(index : Int) -> [Student]{
        var student = fetchData()
        context?.delete(student[index])
        student.remove(at: index)
        do{
            try context?.save()
        }
        catch{
            print("Not Found")
        }
        return student
    }
}

